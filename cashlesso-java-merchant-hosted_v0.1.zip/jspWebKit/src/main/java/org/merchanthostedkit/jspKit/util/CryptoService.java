package org.merchanthostedkit.jspKit.util;

public class CryptoService {
	
	public Scrambler getScrambler(String payId,String salt) throws Exception {
			Scrambler scrambler;
			//Generate Key for that pay ID 
			String key = CustomHasher.generateKey(payId,salt);
			scrambler = new Scrambler(key);
			//scramblerMap.put(payId, scrambler);
			return scrambler;
	}
	
	
	public String decrypt(String payId,String salt,String data) throws Exception {
		Scrambler scrambler = getScrambler(payId,salt);
		return scrambler.decrypt(data);
	}

	public String encrypt(String payId,String salt, String data) throws Exception {
		Scrambler scrambler = getScrambler(payId,salt);
		return scrambler.encrypt(data);
	}
}