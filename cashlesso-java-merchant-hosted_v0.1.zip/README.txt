=== Plugin Name ===
CASHLESSO MERCHANT HOSTED KIT JSP

=== Description of Cashlesso Payment Gateway ===
This is Cashlesso Payment Gateway for Merchant Hosted page. Its Allow you to use Cashlesso payment gateway with the Merchant Hosted Jsp Kit plugin. It is secure to pay online via cashlesso and it is strongly recommended for Indian Payments.


=== Integration of CASHLESSO MERCHANT HOSTED JSP Kit ===
1. We are providing the "jspWebKit-jar-with-dependencies.jar" and JSP files(index.jsp,merchantRequest.jsp,response.jsp). project folder name is "pgHostedWebProject"
2. First Add the "jspWebKit-jar-with-dependencies.jar" into the following locaiton --> src/webapp/Web-INF/lib and also add this jar as external jar 
3. After that add the mentioned jsp files in your project. 

** Note: see the screen shots for better understanding 

=== Docs & Support ===
Docs : For more info See the following document -->  Cashlesso Payment Gateway_Merchant_Hosted_V 0.1.docx
For Support and Issues with Cashlesso MERCHANT HOSTED JSP Kit? mail us on [rajendra.kumar@cashlesso.com].

 
=== Screenshots ===
1. [screenshot-1.PNG] Adding the jspWebKit-jar-with-dependencies.jar location.
2. [screenshot-2.PNG] Adding the Jsp's Location.

=== Configuration ===

1. In index.jsp --> you need to cross check all the input feilds you mentioned correct or not. PAY_ID, Card Details and other details. Return Url as like this --> your server url along with response.jsp
		    Currently, I am using the following return url --> http://localhost:8080/testkit1/response.jsp, you need to change according to your server.  
2. In merchantRequest.jsp --> you need provide your merchant salt key in the following variable --> saltKey. Search the saltKey in the jsp file and enter your salt key.
3. In response.jsp --> you need provide your merchant salt key in the following variable --> saltKey. Search the saltKey in the jsp file and enter your salt key.


Now you can make your payment securely through CASHLESSO by selecting it as the Payment Method at the Checkout stage.
